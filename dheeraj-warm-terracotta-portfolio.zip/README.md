# Gopi Setty Lakshmi Dheeraj — Light Premium Portfolio

## Implementation plan
1. Replace the existing visual system with a bright, editorial light theme: warm off-white canvas, white cards, ink typography, violet/cyan accents.
2. Keep the existing single-page information architecture: hero, projects, skills, education, certifications, opportunity focus, contact.
3. Preserve the profile details and original destinations already present in the source portfolio.
4. Improve discovery with category filters for Embedded & IoT, Software, and AI/ML.
5. Add responsive navigation, scroll progress, active-section navigation, back-to-top, staggered scroll reveals, animated hero orbit, and pointer spotlight on project cards.
6. Respect `prefers-reduced-motion` and disable pointer-follow effects on touch devices.
7. Deploy as a static `index.html` on GitHub Pages; no build step or dependencies are required.

## Publish
1. Back up the current root `index.html` in https://github.com/dheeraj0677/Portfolio.
2. Replace it with this `index.html`.
3. Commit to the repository's Pages deployment branch (usually `main`).
4. Wait for GitHub Pages to deploy, then verify https://dheeraj0677.github.io/Portfolio/.

## Notes
- This package does not push changes to GitHub.
- The existing portfolio's personal details, GitHub repositories, LinkedIn, contact, and certification URLs have been retained.
- Check time-sensitive claims (CGPA, semester, availability and location) before publishing.
- A resume download link is intentionally not fabricated; add it when the final resume file is available.
